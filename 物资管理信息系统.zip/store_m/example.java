import javax.swing.*;

public class example {
    private JButton button1;
    private JButton button2;

    public static void main(String[] args) {
        JFrame frame = new JFrame("example");
        frame.setContentPane(new example().panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    private JPanel panel1;
    private JPasswordField passwordField1;
    private JList list1;
    private JList list2;
    private JList list3;

}
