package store_ma.model;

public class manage {
    private int userID;
    private int goodsID;
    private int warehouseId;

    public int getUserID(){return userID;}

    public void setUserID(int userID){this.userID = userID;}

    public int getGoodsID(){return goodsID;}

    public void setGoodsID(int goodsID){this.goodsID = goodsID;}

    public int getWarehouseId(){return warehouseId;}

    public void setWarehouseId(int warehouseId){this.warehouseId = warehouseId;}
}