package store_ma.model;

public class NP {
    private int number ;
    private int price;

    public void setNumber(int number){this.number = number;}

    public int getNumber(){return number;}

    public void setPrice(int price){this.price = price;}

    public int getPrice(){return price;}
}
