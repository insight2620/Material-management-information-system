package store_ma.model;

public class supplier {
    private int supplierId;
    private String supplierName;
    private String supplierAddress;
    private int supplirerPhone;

    public int getSupplierId(){return supplierId;}

    public void setSupplierId(int supplierId){this.supplierId=supplierId;}

    public String getSupplierName(){return supplierName;}

    public void setSupplierName(String supplierName){this.supplierName = supplierName;}

    public String getSupplierAddress(){return supplierAddress;}

    public void setSupplierAddress(String supplierAddress){this.supplierAddress = supplierAddress;}

    public int getSupplierPhone(){return supplirerPhone;}

    public void setSupplierPhone(int supplirerPhone){this.supplirerPhone = supplirerPhone;}

}
