package store_ma.view;


import com.model.Goods;
import com.view.CancelUserFrame;

import javax.swing.*;

import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MainFrame  extends JFrame {
    //static Icon icon=new ImageIcon("ai.jpg");//Ҫ��ʾ��ͼ��
    ImageIcon background;
    JLabel labelbackground;
    JPanel myBackgroundPanel;


    /*��ť*/
    private JButton SgoodsmoveButton;/*�ֿ����ʹ���*/
    private JButton SbasicinfomationButton;/*������Ϣ����*/
    private JButton SqueryStatisticsButton;/*��ѯͳ��*/
    private JButton SusermanageButton;/*�û�����*/
    private JTable table;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    MainFrame frame = new MainFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }

    class IPanel extends JPanel{
        public void paintConmponent(Graphics g){
            Image i = new ImageIcon("ai.jpg").getImage();
            g.drawImage(i,10,10,this);
        }
    }

    class MPanel extends JPanel{
       public void paintComponent(Graphics g){
           g.setColor(Color.green);
           g.fillRect(20,50,100,100);
       }

    }

    public MainFrame() {
        setTitle("���ʹ���ϵͳ");
        setBounds(140, 80, 1213, 750);

        /*����ͼ�Ļ�ȡ*/
        //this.getContentPane().add(new   MPanel());
        //this.getContentPane().add(new IPanel());
        background = new ImageIcon("F://Code_document//store_m//ai.jpg");
        labelbackground = new JLabel(background);
        labelbackground.setBounds(0,0,500,400);//background.getIconWidth(),background.getIconHeight());
        myBackgroundPanel = new JPanel();//����Ϊ���Լ���	//���ҵ��������Ϊ�������,myPanel��this.getContentPane()��ͬ
        myBackgroundPanel.add(labelbackground);

        /*�������÷���*/
        //myBackgroundPanel.setOpaque(false);					//���ҵ��������Ϊ������
        //myBackgroundPanel.setLayout(new FlowLayout());		//���ҵ��������Ϊ��������
        //this.getLayeredPane().setLayout(null);		//�ѷֲ����Ĳ����ÿ�
        //this.getLayeredPane().add(labelbackground, new Integer(Integer.MIN_VALUE));		//�ѱ�ǩ���ӵ��ֲ�������ײ�
        //this.getContentPane().add(myBackgroundPanel);


        SgoodsmoveButton = new JButton("�ֿ����ʹ���");
        SgoodsmoveButton.setFont(new Font("΢���ź�", Font.PLAIN, 16));

        SbasicinfomationButton = new JButton("������Ϣ����");
        SbasicinfomationButton.setFont(new Font("΢���ź�", Font.PLAIN, 16));

        SqueryStatisticsButton = new JButton("��ѯͳ��");
        SqueryStatisticsButton.setFont(new Font("΢���ź�", Font.PLAIN, 16));

        SusermanageButton =new JButton("�û�����");
        SusermanageButton.setFont(new Font("΢���ź�", Font.PLAIN, 16));

        /*��
        table = new JTable();
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                selectedTableRow(me);
            }
        });
        table.setModel(new DefaultTableModel(
                new Object[][]{
                },
                new String[]{
                        "+"
                                + "isbn", "class", "subclass", "name", "author", "date"
                }
        ) {
            boolean[] columnEditables = new boolean[]{
                    false, true, false, false, false, false
            };

            public boolean isCellEditable(int row, int column) {
                return columnEditables[column];
            }
        });
        table.getColumnModel().getColumn(5).setPreferredWidth(98);
        scrollPane.setViewportView(table);
        getContentPane().setLayout(groupLayout);
        setTable(new Goods());*/



            /*�������*/

        GroupLayout groupLayout = new GroupLayout(getContentPane());
        groupLayout.setHorizontalGroup(
                groupLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(groupLayout.createSequentialGroup()
                                .addGap(49)
                                .addComponent(SgoodsmoveButton, GroupLayout.PREFERRED_SIZE, 77, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(SbasicinfomationButton, GroupLayout.PREFERRED_SIZE, 158, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(SqueryStatisticsButton, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(SusermanageButton, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(59, Short.MAX_VALUE))
                        .addGroup(GroupLayout.Alignment.TRAILING, groupLayout.createSequentialGroup()
                                .addContainerGap(35, Short.MAX_VALUE)
                                .addComponent(myBackgroundPanel, GroupLayout.PREFERRED_SIZE, 529, GroupLayout.PREFERRED_SIZE)
                                .addGap(19))
        );
        groupLayout.setVerticalGroup(
                groupLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(groupLayout.createSequentialGroup()
                                .addGap(32)
                                .addGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(myBackgroundPanel)
                                        .addComponent(SusermanageButton, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(SqueryStatisticsButton)
                                        .addComponent(SbasicinfomationButton))
                                .addGap(18)
                                .addComponent(SgoodsmoveButton, GroupLayout.PREFERRED_SIZE, 311, GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(34, Short.MAX_VALUE))
        );

        getContentPane().setLayout(groupLayout);
    }


    protected void selectedTableRow(MouseEvent me) {
        //DefaultTableModel dft = (DefaultTableModel) table.getModel();
        //goodsNameTextField.setText(dft.getValueAt(table.getSelectedRow(), 1).toString());
    }
}
